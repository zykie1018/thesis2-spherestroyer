﻿public enum SoundType
{
    Input,
    Success,
    Highscore,
    End
}