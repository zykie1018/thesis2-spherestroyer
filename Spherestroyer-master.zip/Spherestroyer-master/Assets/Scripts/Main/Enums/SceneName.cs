﻿public enum SceneName
{
    None,
    Menu,
    Gameplay
}
