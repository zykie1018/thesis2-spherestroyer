﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ToggleMusicTag : IComponentData
{
}