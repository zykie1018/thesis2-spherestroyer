﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct UpdateMenuUITag : IComponentData
{
}