﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ApplyGravityTag : IComponentData
{
}