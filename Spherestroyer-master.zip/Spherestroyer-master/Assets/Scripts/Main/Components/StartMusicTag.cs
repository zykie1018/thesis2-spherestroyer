﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct StartMusicTag : IComponentData
{
}