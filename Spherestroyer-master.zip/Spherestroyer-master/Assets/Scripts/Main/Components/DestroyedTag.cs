﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct DestroyedTag : IComponentData
{
}