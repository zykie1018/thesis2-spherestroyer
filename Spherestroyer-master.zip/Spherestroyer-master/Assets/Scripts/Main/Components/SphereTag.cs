﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct SphereTag : IComponentData
{
}