﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct StartGameTag : IComponentData
{
}