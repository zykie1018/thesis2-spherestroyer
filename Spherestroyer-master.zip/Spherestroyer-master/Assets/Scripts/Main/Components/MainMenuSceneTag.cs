﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct MainMenuSceneTag : IComponentData
{
}
