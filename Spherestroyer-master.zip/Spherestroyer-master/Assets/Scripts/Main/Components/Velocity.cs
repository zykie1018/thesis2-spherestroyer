﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct MoveDrag : IComponentData
{
    public float Value;
}