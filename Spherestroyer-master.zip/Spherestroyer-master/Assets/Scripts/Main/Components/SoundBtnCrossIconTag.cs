﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct SoundBtnCrossIconTag : IComponentData
{
}