﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct SpikeTag : IComponentData
{
}