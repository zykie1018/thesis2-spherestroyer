﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ChangeToGameplayTag : IComponentData
{
}