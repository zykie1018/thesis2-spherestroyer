﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ToggleSoundsTag : IComponentData
{
}