﻿using Unity.Entities;

public struct SpikeReference : IComponentData
{
    public Entity Entity;
}