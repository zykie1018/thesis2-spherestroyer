﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct GameSceneTag : IComponentData
{
}