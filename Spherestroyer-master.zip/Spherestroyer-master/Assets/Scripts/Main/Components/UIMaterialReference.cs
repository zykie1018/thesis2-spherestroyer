﻿using Unity.Entities;

public struct UIMaterialReference : IBufferElementData
{
    public Entity materialEntity;
}