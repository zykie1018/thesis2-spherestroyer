﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct EnableOnStartTag : IComponentData
{
}