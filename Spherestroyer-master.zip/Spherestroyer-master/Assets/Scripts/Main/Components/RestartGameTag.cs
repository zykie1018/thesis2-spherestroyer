﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct RestartGameTag : IComponentData
{
}