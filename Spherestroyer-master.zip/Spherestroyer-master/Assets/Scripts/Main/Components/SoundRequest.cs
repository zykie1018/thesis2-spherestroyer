﻿using Unity.Entities;

public struct SoundRequest : IComponentData
{
    public SoundType Value;
}