﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct HideableSymbolTag : IComponentData
{
}