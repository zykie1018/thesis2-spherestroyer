﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ParticleShardTag : IComponentData
{
}