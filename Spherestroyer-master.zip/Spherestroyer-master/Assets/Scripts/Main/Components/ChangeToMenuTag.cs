﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ChangeToMenuTag : IComponentData
{
}