﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct UpdateMaterialTag : IComponentData
{
}