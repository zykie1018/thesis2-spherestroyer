﻿using Unity.Entities;

public struct GameEnd : IComponentData
{
    public float TimeToEnd;
}