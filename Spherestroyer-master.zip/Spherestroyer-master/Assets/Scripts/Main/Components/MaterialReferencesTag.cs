﻿using System;
using Unity.Entities;

public struct MaterialReferencesTag : IComponentData
{
}