﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct ResetTag : IComponentData
{
}