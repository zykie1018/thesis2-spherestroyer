﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct InputTag : IComponentData
{
}