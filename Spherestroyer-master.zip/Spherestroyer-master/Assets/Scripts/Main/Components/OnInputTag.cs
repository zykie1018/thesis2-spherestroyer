﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct OnInputTag : IComponentData
{
}