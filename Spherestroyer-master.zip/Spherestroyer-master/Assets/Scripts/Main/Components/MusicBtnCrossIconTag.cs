﻿using Unity.Entities;

[GenerateAuthoringComponent]
public struct MusicBtnCrossIconTag : IComponentData
{
}